#!/bin/bash
HTEM model -T0 0 -Tr 0,1200,121 -Pr 0,10,11 -weight 2 -read Elasticity_cold+NVT_s4.dat -plt eps