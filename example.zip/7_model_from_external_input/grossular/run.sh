#!/bin/bash
HTEM model -T0 0 -Tr 0,2000,21 -Pr 0,25,26 -weight 2 -read grossular.dat -plt png -lt C -M 22.52205

