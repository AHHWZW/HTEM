#!/bin/bash
HTEM model -T0 0 -Tr 0,2500,26 -Pr 0,80,41 -weight 2 -read Al2O3.dat -plt png -lt RI -M 20.3922
