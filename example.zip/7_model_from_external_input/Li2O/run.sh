#!/bin/bash
HTEM model -T0 0 -Tr 0,1700,18 -Pr 0,30,31 -weight 2 -read Li2O.dat -plt png -lt C -M 9.959666666666667
