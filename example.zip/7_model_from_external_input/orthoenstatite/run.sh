#!/bin/bash
HTEM model -T0 300 -Tr 0,2000,21 -Pr 0,10,11 -weight 2 -read MgSiO3.dat -plt png -lt O -M 10.478
