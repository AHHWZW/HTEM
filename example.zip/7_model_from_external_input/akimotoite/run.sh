#!/bin/bash
HTEM model -T0 0 -Tr 0,2000,21 -Pr 0,30,31 -weight 2 -read akimotoite.dat -plt png -lt RII -M 20.86590000000001
