#!/bin/bash
HTEM model -T0 100 -Tr 0,1000,11 -Pr 0,60,31 -weight 2 -read Cu.dat -plt png -lt C -M 63.546
